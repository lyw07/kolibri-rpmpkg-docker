"""
Do not import anything from the rest of Kolibri in this module, it's crucial
that it can be loaded without the settings/configuration/django stack!
"""
