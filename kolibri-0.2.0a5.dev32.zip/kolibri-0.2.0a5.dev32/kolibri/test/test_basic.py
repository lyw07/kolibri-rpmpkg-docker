"""
Tests for `kolibri` module.
"""

# import pytest
# import kolibri

import logging

logger = logging.getLogger(__name__)


class TestKolibri_prototype(object):

    @classmethod
    def setup_class(cls):
        pass

    def test_something(self):
        logger.debug("This is the main Kolibri integration tests")

    @classmethod
    def teardown_class(cls):
        pass
