from __future__ import absolute_import, print_function, unicode_literals

import sys

if __name__ == "__main__":

    from kolibri.utils.cli import main
    main(args=sys.argv[1:])
