
Credits
=======

Development Lead and Copyright Holder
-------------------------------------

* Learning Equality – info@learningequality.org

Community
---------

Please feel free to add your name on this list if you do a PR!

* Benjamin Bach (benjaoming)
* Michael Gallaspy (MCGallaspy)
* Richard Tibbles (rtibbles)
* Jamie Alexandre (jamalex)
* David Cañas (dxcanas)
* Eli Dai (66eli77)
* Devon Rueckner (indirectlylit)
* Rafael Aguayo (ralphiee22)
* Christian Memije (christianmemije)
* Radina Matic (radinamatic)
