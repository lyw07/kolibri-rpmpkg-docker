from __future__ import absolute_import, print_function, unicode_literals

from .base import *  # noqa

KOLIBRI_SKIP_AUTO_DATABASE_MIGRATION = True
